"use strict";
cc._RF.push(module, 'fc122qToQhByr8kag01h1T3', 'Pipe');
// Scripts/Pipe.js

"use strict";

cc.Class({
    extends: cc.Component,

    properties: {
        // 小鸟通过管道与否的标志位
        isPassed: false
    },

    // use this for initialization
    onLoad: function onLoad() {},

    init: function init(type) {
        // 设置管道的类型（上或下）
        this.type = type;
    }
});

cc._RF.pop();